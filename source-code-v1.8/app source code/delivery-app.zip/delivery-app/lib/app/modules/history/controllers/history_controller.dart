import 'package:get/get.dart';

class HistoryController extends GetxController {}
