<?php

namespace App\Enums;

interface CurrencyPosition
{
    const LEFT  = 5;
    const RIGHT = 10;
}
