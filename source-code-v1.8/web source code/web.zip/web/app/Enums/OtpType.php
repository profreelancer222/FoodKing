<?php

namespace App\Enums;

interface OtpType
{
    const BOTH  = 5;
    const SMS   = 10;
    const EMAIL = 15;
}
