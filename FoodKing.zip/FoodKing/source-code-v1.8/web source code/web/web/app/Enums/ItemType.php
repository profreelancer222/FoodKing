<?php
namespace App\Enums;

interface ItemType
{
    const VEG     = 5;
    const NON_VEG = 10;
}
