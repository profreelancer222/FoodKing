<?php

namespace App\Enums;

interface Activity
{
     const ENABLE  = 5;
     const DISABLE = 10;
}
