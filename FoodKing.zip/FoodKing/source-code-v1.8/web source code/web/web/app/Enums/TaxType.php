<?php

namespace App\Enums;

interface TaxType
{
    const FIXED      = 5;
    const PERCENTAGE = 10;
}