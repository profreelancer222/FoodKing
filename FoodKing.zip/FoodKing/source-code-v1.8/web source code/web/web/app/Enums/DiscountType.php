<?php

namespace App\Enums;

interface DiscountType
{
    const FIXED      = 5;
    const PERCENTAGE = 10;
}